/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica3clasesjava;

/**
 *
 * @author Han-S
 */
public class SimbGram {

    String _elem;

    public SimbGram(String sValor) {
        _elem = sValor;
    }

    public String Elem() {
        return _elem;
    }
}
